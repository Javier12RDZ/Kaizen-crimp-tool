import { useState, useEffect } from 'react';
import { Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import AddRecordPage from './pages/AddRecordPage';
import ImageModal from './components/ImageModal';
import './index.css';

function App() {
  const [items, setItems] = useState([]);
  const [dataVersion, setDataVersion] = useState(0);
  const [error, setError] = useState(null);
  const [editingItem, setEditingItem] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [viewingImage, setViewingImage] = useState(null);

  // Use window.location.hostname to make the API URL dynamic
  const API_BASE_URL = `http://${window.location.hostname}:3001`;

  const fetchData = () => {
    setError(null);
    fetch(`${API_BASE_URL}/api/items`)
      .then(response => {
        if (!response.ok) throw new Error('La respuesta de la red no fue correcta');
        return response.json();
      })
      .then(data => {
        setItems(data.items || []);
        setDataVersion(data.version || 0);
      })
      .catch(error => {
        console.error('Error al obtener datos:', error);
        setError(error.message);
      });
  };

  const handleDelete = (itemId) => {
    if (!window.confirm('¿Estás seguro de que quieres eliminar este registro?')) return;

    fetch(`${API_BASE_URL}/api/items/${itemId}`, { 
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ version: dataVersion })
    })
      .then(async response => {
        if (response.status === 409) {
          const data = await response.json();
          throw new Error(data.message || 'Conflicto de versiones. Por favor, recarga la página.');
        }
        if (!response.ok) throw new Error('Error al eliminar el registro');
        fetchData();
      })
      .catch(error => {
        console.error('Error al eliminar:', error);
        alert(error.message); // Show alert to user
        setError(error.message);
      });
  };

  const handleUpdateItem = (formData) => {
    const itemId = formData.get('id');

    if (!itemId) {
        alert('Error: El ID del registro no fue encontrado. No se puede actualizar.');
        setError('Error: El ID del registro no fue encontrado en el formulario.');
        return;
    }

    formData.append('version', dataVersion);

    fetch(`${API_BASE_URL}/api/items/${itemId}`, {
      method: 'PUT',
      body: formData,
    })
    .then(async response => {
      if (response.status === 409) {
        const data = await response.json();
        throw new Error(data.message || 'Conflicto de versiones. Por favor, recarga la página.');
      }
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ message: `Código de estado ${response.status}` }));
        throw new Error(`Error al actualizar el registro: ${errorData.message}`);
      }
      setEditingItem(null);
      fetchData();
    })
    .catch(error => {
      console.error('Error al actualizar:', error);
      alert(error.message);
      setError(error.message);
    });
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleViewImage = (imageUrl) => {
    setViewingImage(imageUrl);
  };

  const handleCloseImage = () => {
    setViewingImage(null);
  };

  const categories = [...new Set(items.map(item => item.category))];

  const filteredItems = items.filter(item => {
    if (selectedCategory !== 'All' && item.category !== selectedCategory) {
      return false;
    }
    const term = searchTerm.toLowerCase();
    if (!term) return true;
    return (
      item.category.toLowerCase().includes(term) ||
      String(item.contact_number).toLowerCase().includes(term) ||
      String(item.tool_part_number).toLowerCase().includes(term) ||
      String(item.dado_number).toLowerCase().includes(term) ||
      (item.comments && item.comments.toLowerCase().includes(term))
    );
  });

  return (
    <>
      <Routes>
        <Route 
          path="/" 
          element={
            <HomePage
              items={filteredItems}
              error={error}
              searchTerm={searchTerm}
              setSearchTerm={setSearchTerm}
              editingItem={editingItem}
              setEditingItem={setEditingItem}
              handleDelete={handleDelete}
              handleUpdateItem={handleUpdateItem}
              onViewImage={handleViewImage}
              categories={categories}
              dataVersion={dataVersion}
              fetchData={fetchData}
              selectedCategory={selectedCategory}
              setSelectedCategory={setSelectedCategory}
            />
          } 
        />
        <Route 
          path="/add" 
          element={
            <AddRecordPage
              categories={categories}
              currentVersion={dataVersion}
              onItemAdded={fetchData}
            />
          } 
        />
      </Routes>
      <ImageModal imageUrl={viewingImage} onClose={handleCloseImage} />
    </>
  );
}

export default App;
