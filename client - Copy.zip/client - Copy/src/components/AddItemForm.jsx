import React, { useState, useEffect } from 'react';

function AddItemForm({ categories, onItemAdded, currentVersion }) {
    const [message, setMessage] = useState('');
    const [selectedCategory, setSelectedCategory] = useState('');
    const [newCategory, setNewCategory] = useState('');

    const API_BASE_URL = `http://${window.location.hostname}:3001`;

    const handleSubmit = async (e) => {
        e.preventDefault();
        setMessage('');

        const formData = new FormData(e.target);
        const finalCategory = selectedCategory === '__NEW__' ? newCategory : selectedCategory;

        if (!finalCategory) {
            setMessage('La categoría no puede estar vacía.');
            return;
        }

        // FormData doesn't include select value if it's managed by state, so we set it manually.
        formData.set('category', finalCategory);
        formData.append('version', currentVersion);

        // Clean up empty files
        if (formData.get('contact_image') && formData.get('contact_image').size === 0) {
            formData.delete('contact_image');
        }
        if (formData.get('tool_image') && formData.get('tool_image').size === 0) {
            formData.delete('tool_image');
        }
        if (formData.get('dado_image') && formData.get('dado_image').size === 0) {
            formData.delete('dado_image');
        }

        try {
            const response = await fetch(`${API_BASE_URL}/api/items`, {
                method: 'POST',
                body: formData,
            });

            if (response.ok) {
                setMessage('Registro agregado con éxito.');
                e.target.reset();
                setNewCategory('');
                setSelectedCategory(categories[0] || '');
                if (onItemAdded) onItemAdded(); // Refresh data on success
                return;
            }

            // Handle errors if response is not ok
            const result = await response.json();
            if (response.status === 409) {
                // Conflict error: inform user and refresh data
                setMessage('Los datos cambiaron. Intente guardar de nuevo.');
                if (onItemAdded) onItemAdded(); // Refresh data in parent
            } else {
                // Other server errors
                throw new Error(result.message || 'Error al agregar el registro');
            }

        } catch (error) {
            // This will catch network errors or non-409 server errors
            setMessage(`Error: ${error.message}`);
            console.error('Add item error:', error);
        }
    };

    return (
        <div className="add-item-form">
            <h3>Agregar Nuevo Registro</h3>
            <form onSubmit={handleSubmit}>
                <select value={selectedCategory} onChange={(e) => setSelectedCategory(e.target.value)} name="category_select" required>
                    <option value="" disabled>-- Seleccione una categoría --</option>
                    {categories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                    <option value="__NEW__">-- Nueva Categoría --</option>
                </select>

                {selectedCategory === '__NEW__' && (
                    <input 
                        type="text" 
                        name="new_category_name" 
                        placeholder="Nombre de la nueva categoría" 
                        value={newCategory} 
                        onChange={(e) => setNewCategory(e.target.value)} 
                        required 
                    />
                )}

                <input type="text" name="contact_number" placeholder="Nº Contacto" required />
                <input type="text" name="tool_part_number" placeholder="Nº Parte Herramienta" required />
                <input type="text" name="dado_number" placeholder="Nº Dado" />
                <input type="text" name="comments" placeholder="Comentarios" />
                <label>Imagen Contacto</label>
                <input type="file" name="contact_image" accept="image/*" />
                <label>Imagen Herramienta</label>
                <input type="file" name="tool_image" accept="image/*" />
                <label>Imagen Dado</label>
                <input type="file" name="dado_image" accept="image/*" />
                <button type="submit">Agregar Registro</button>
            </form>
            {message && <p>{message}</p>}
        </div>
    );
}

export default AddItemForm;
