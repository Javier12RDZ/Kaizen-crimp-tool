import React, { useState, useEffect } from 'react';

const API_BASE_URL = `http://${window.location.hostname}:3001`;

const EditableImage = ({ imageName, imageType, onViewImage, onImageDeleted }) => {
    if (!imageName) {
        return (
            <div className="form-group">
                <label>Imagen {imageType.split('_')[0]}</label>
                <p>Sin imagen</p>
                <input type="file" name={imageType} accept="image/*" />
            </div>
        );
    }

    const imageUrl = `${API_BASE_URL}/uploads/${imageName}`;

    return (
        <div className="form-group">
            <label>Imagen {imageType.split('_')[0]}</label>
            <div className="image-preview-container">
                <img 
                    src={imageUrl} 
                    alt={imageName} 
                    className="table-image" 
                    onClick={() => onViewImage(imageUrl)}
                />
                <button type="button" className="delete-image-btn" onClick={() => onImageDeleted(imageType, imageName)}>
                    Eliminar Imagen
                </button>
            </div>
            <input type="file" name={imageType} accept="image/*" />
        </div>
    );
};

function EditModal({ item, categories, onSave, onClose, onViewImage }) {
    const [editedItem, setEditedItem] = useState(item);
    const [deletedImages, setDeletedImages] = useState({});

    useEffect(() => {
        setEditedItem(item);
        setDeletedImages({}); // Reset on new item
    }, [item]);

    if (!item) return null;

    const handleChange = (e) => {
        const { name, value } = e.target;
        setEditedItem(prev => ({ ...prev, [name]: value }));
    };

    const handleImageDeleted = (imageType, imageName) => {
        // Visually remove the image by updating the item state
        setEditedItem(prev => ({ ...prev, [imageType]: null }));
        // Mark for deletion on save
        setDeletedImages(prev => ({ ...prev, [imageType]: true }));
    };

    const handleSave = (e) => {
        e.preventDefault();
        const formData = new FormData(e.target);

        // Append flags for deleted images
        for (const imageType in deletedImages) {
            if (deletedImages[imageType]) {
                formData.append(`delete_${imageType}`, 'true');
            }
        }

        onSave(formData);
    };

    return (
        <div className="modal-backdrop">
            <div className="modal-content">
                <h2>Editar Registro</h2>
                <form onSubmit={handleSave}>
                    <input type="hidden" name="id" value={editedItem.id} />

                    {/* ... other form groups ... */}
                    <div className="form-group">
                        <label>Categoría</label>
                        <input 
                            type="text" 
                            name="category" 
                            value={editedItem.category} 
                            onChange={handleChange} 
                            list="category-suggestions"
                            required 
                        />
                        <datalist id="category-suggestions">
                            {categories.map(cat => <option key={cat} value={cat} />)}
                        </datalist>
                    </div>
                    <div className="form-group">
                        <label>Nº Contacto</label>
                        <input type="text" name="contact_number" value={editedItem.contact_number} onChange={handleChange} required />
                    </div>
                    <div className="form-group">
                        <label>Nº Parte Herramienta</label>
                        <input type="text" name="tool_part_number" value={editedItem.tool_part_number} onChange={handleChange} required />
                    </div>
                    <div className="form-group">
                        <label>Nº Dado</label>
                        <input type="text" name="dado_number" value={editedItem.dado_number || ''} onChange={handleChange} />
                    </div>
                    <div className="form-group">
                        <label>Comentarios</label>
                        <input type="text" name="comments" value={editedItem.comments || ''} onChange={handleChange} />
                    </div>

                    {/* Refactored Image Fields */}
                    <EditableImage 
                        imageName={editedItem.contact_image} 
                        imageType="contact_image" 
                        onViewImage={onViewImage} 
                        onImageDeleted={handleImageDeleted} 
                    />
                    <EditableImage 
                        imageName={editedItem.tool_image} 
                        imageType="tool_image" 
                        onViewImage={onViewImage} 
                        onImageDeleted={handleImageDeleted} 
                    />
                    <EditableImage 
                        imageName={editedItem.dado_image} 
                        imageType="dado_image" 
                        onViewImage={onViewImage} 
                        onImageDeleted={handleImageDeleted} 
                    />

                    <div className="modal-actions">
                        <button type="button" onClick={onClose}>Cancelar</button>
                        <button type="submit">Guardar Cambios</button>
                    </div>
                </form>
            </div>
        </div>
    );
}


export default EditModal;