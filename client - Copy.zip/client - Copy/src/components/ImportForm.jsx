import React, { useState } from 'react';

function ImportForm({ onImportSuccess, currentVersion }) {
    const [file, setFile] = useState(null);
    const [message, setMessage] = useState('');

    const API_BASE_URL = `http://${window.location.hostname}:3001`;

    const handleFileChange = (e) => {
        setFile(e.target.files[0]);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!file) {
            setMessage('Por favor, selecciona un archivo.');
            return;
        }

        const formData = new FormData();
        formData.append('file', file);
        formData.append('version', currentVersion);

        try {
            setMessage('Importando...');
            const response = await fetch(`${API_BASE_URL}/api/import`, {
                method: 'POST',
                body: formData,
            });

            if (response.ok) {
                const result = await response.json();
                setMessage(`¡Éxito! Se importaron ${result.itemCount} registros.`);
                if (onImportSuccess) onImportSuccess();
                e.target.reset();
                setFile(null);
                return;
            }

            const result = await response.json();
            if (response.status === 409) {
                setMessage('Los datos cambiaron. Intente importar de nuevo.');
                if (onImportSuccess) onImportSuccess(); // Refresh data
            } else {
                throw new Error(result.message || 'Error al importar');
            }

        } catch (error) {
            setMessage(`Error: ${error.message}`);
            console.error('Import error:', error);
        }
    };

    return (
        <div className="import-form">
            <h3>Importar desde Excel</h3>
            <form onSubmit={handleSubmit}>
                <input type="file" onChange={handleFileChange} accept=".xlsx, .xls" />
                <button type="submit">Importar</button>
            </form>
            {message && <p>{message}</p>}
        </div>
    );
}

export default ImportForm;
