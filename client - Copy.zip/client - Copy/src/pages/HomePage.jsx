import { Link } from 'react-router-dom';
import DataTable from '../components/DataTable';
import EditModal from '../components/EditModal';
import CategoryTabs from '../components/CategoryTabs';

function HomePage({
  items,
  error,
  searchTerm,
  setSearchTerm,
  editingItem,
  setEditingItem,
  handleDelete,
  handleUpdateItem,
  onViewImage,
  categories,
  dataVersion,
  fetchData,
  selectedCategory,
  setSelectedCategory
}) {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Gestor de Herramientas de Crimpeado</h1>
      </header>
      <main>
        <div className="forms-container">
          <Link to="/add">
            <button className="add-new-button">Agregar o Importar Registros</button>
          </Link>
        </div>
        <hr />
        <h2>Listado de herramientas</h2>
        <CategoryTabs 
          categories={categories}
          selectedCategory={selectedCategory}
          onSelectCategory={setSelectedCategory}
        />
        <div className="toolbar">
          <input 
            type="text"
            placeholder="Buscar en la tabla..."
            className="search-input"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        {error && <p style={{ color: 'red' }}>Error: {error}</p>}
        <DataTable items={items} onEdit={setEditingItem} onDelete={handleDelete} onViewImage={onViewImage} />
      </main>
      {editingItem && (
        <EditModal 
          item={editingItem} 
          categories={categories}
          onSave={handleUpdateItem} 
          onClose={() => setEditingItem(null)} 
          onViewImage={onViewImage}
        />
      )}
    </div>
  );
}

export default HomePage;
