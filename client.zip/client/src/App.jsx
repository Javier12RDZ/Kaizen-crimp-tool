import { useState, useEffect } from 'react';
import './index.css';
import ImportForm from './components/ImportForm';
import AddItemForm from './components/AddItemForm';
import DataTable from './components/DataTable';
import EditModal from './components/EditModal';

function App() {
  const [items, setItems] = useState([]);
  const [dataVersion, setDataVersion] = useState(0);
  const [error, setError] = useState(null);
  const [editingItem, setEditingItem] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');

  const fetchData = () => {
    setError(null);
    fetch('http://localhost:3001/api/items')
      .then(response => {
        if (!response.ok) throw new Error('La respuesta de la red no fue correcta');
        return response.json();
      })
      .then(data => {
        setItems(data.items || []);
        setDataVersion(data.version || 0);
      })
      .catch(error => {
        console.error('Error al obtener datos:', error);
        setError(error.message);
      });
  };

  const handleDelete = (itemId) => {
    if (!window.confirm('¿Estás seguro de que quieres eliminar este registro?')) return;

    fetch(`http://localhost:3001/api/items/${itemId}`, { 
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ version: dataVersion })
    })
      .then(async response => {
        if (response.status === 409) {
          const data = await response.json();
          throw new Error(data.message || 'Conflicto de versiones. Por favor, recarga la página.');
        }
        if (!response.ok) throw new Error('Error al eliminar el registro');
        fetchData();
      })
      .catch(error => {
        console.error('Error al eliminar:', error);
        alert(error.message); // Show alert to user
        setError(error.message);
      });
  };

  const handleUpdateItem = (formData) => {
    const itemId = formData.get('id');
    formData.append('version', dataVersion); // Add version to the form data

    fetch(`http://localhost:3001/api/items/${itemId}`, {
      method: 'PUT',
      body: formData,
    })
    .then(async response => {
      if (response.status === 409) {
        const data = await response.json();
        throw new Error(data.message || 'Conflicto de versiones. Por favor, recarga la página.');
      }
      if (!response.ok) throw new Error('Error al actualizar el registro');
      setEditingItem(null);
      fetchData();
    })
    .catch(error => {
      console.error('Error al actualizar:', error);
      alert(error.message); // Show alert to user
      setError(error.message);
    });
  };

  useEffect(() => {
    fetchData();
  }, []);

  const categories = [...new Set(items.map(item => item.category))];

  const filteredItems = items.filter(item => {
    const term = searchTerm.toLowerCase();
    return (
      item.category.toLowerCase().includes(term) ||
      String(item.contact_number).toLowerCase().includes(term) ||
      String(item.tool_part_number).toLowerCase().includes(term) ||
      (item.comments && item.comments.toLowerCase().includes(term))
    );
  });

  return (
    <div className="App">
      <header className="App-header">
        <h1>Gestor de Herramientas de Crimpeado</h1>
      </header>
      <main>
        <div className="forms-container">
          <ImportForm onImportSuccess={fetchData} currentVersion={dataVersion} />
          <AddItemForm categories={categories} onItemAdded={fetchData} currentVersion={dataVersion} />
        </div>
        <hr />
        <h2>Datos Actuales</h2>
        <div className="toolbar">
          <input 
            type="text"
            placeholder="Buscar en la tabla..."
            className="search-input"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        {error && <p style={{ color: 'red' }}>Error: {error}</p>}
        <DataTable items={filteredItems} onEdit={setEditingItem} onDelete={handleDelete} />
      </main>
      {editingItem && (
        <EditModal 
          item={editingItem} 
          categories={categories}
          onSave={handleUpdateItem} 
          onClose={() => setEditingItem(null)} 
        />
      )}
    </div>
  );
}

export default App;