import React, { useRef, useState, useEffect } from 'react';
import './CategoryTabs.css';

const CategoryTabs = ({ categories, selectedCategory, onSelectCategory }) => {
  const scrollContainerRef = useRef(null);
  const [isOverflowing, setIsOverflowing] = useState(false);

  const checkOverflow = () => {
    const container = scrollContainerRef.current;
    if (container) {
      // scrollWidth is the width of the content, clientWidth is the visible width of the container
      setIsOverflowing(container.scrollWidth > container.clientWidth);
    }
  };

  useEffect(() => {
    checkOverflow();
    window.addEventListener('resize', checkOverflow);
    return () => window.removeEventListener('resize', checkOverflow);
  }, [categories]); // Re-check when categories change

  const scroll = (scrollOffset) => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollLeft += scrollOffset;
    }
  };

  const allCategories = ['All', ...categories];

  return (
    <div className="category-tabs-container">
      {isOverflowing && (
        <button className="scroll-button" onClick={() => scroll(-150)}>
          &lt;
        </button>
      )}
      <div className="tabs-wrapper" ref={scrollContainerRef}>
        {allCategories.map((category) => (
          <button
            key={category}
            className={`tab-button ${selectedCategory === category ? 'active' : ''}`}
            onClick={() => onSelectCategory(category)}
          >
            {category}
          </button>
        ))}
      </div>
      {isOverflowing && (
        <button className="scroll-button" onClick={() => scroll(150)}>
          &gt;
        </button>
      )}
    </div>
  );
};

export default CategoryTabs;
