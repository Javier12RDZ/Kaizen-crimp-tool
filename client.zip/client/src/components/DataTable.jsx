import React from 'react';

const ImageCell = ({ imageName }) => {
    if (!imageName) return null;
    const imageUrl = `http://localhost:3001/uploads/${imageName}`;
    return <img src={imageUrl} alt={imageName} className="table-image" />;
};

function DataTable({ items, onEdit, onDelete }) {
    if (!items || items.length === 0) {
        return <p>No hay datos para mostrar.</p>;
    }

    return (
        <table className="data-table">
            <thead>
                <tr>
                    <th>Categoría</th>
                    <th>Nº Contacto</th>
                    <th>Imagen Contacto</th>
                    <th>Nº Parte Herramienta</th>
                    <th>Imagen Herramienta</th>
                    <th>Comentarios</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                {items.map((item) => (
                    <tr key={item.id}>
                        <td>{item.category}</td>
                        <td>{item.contact_number}</td>
                        <td><ImageCell imageName={item.contact_image} /></td>
                        <td>{item.tool_part_number}</td>
                        <td><ImageCell imageName={item.tool_image} /></td>
                        <td>{item.comments}</td>
                        <td className="actions-cell">
                            <button onClick={() => onEdit(item)} className="edit-btn">
                                Editar
                            </button>
                            <button onClick={() => onDelete(item.id)} className="delete-btn">
                                Eliminar
                            </button>
                        </td>
                    </tr>
                ))}
            </tbody>
        </table>
    );
}

export default DataTable;
