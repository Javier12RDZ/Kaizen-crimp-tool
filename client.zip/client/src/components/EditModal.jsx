import React, { useState, useEffect } from 'react';

const ImageCell = ({ imageName }) => {
    if (!imageName) return <p>Sin imagen</p>;
    const imageUrl = `http://localhost:3001/uploads/${imageName}`;
    return <img src={imageUrl} alt={imageName} className="table-image" />;
};

function EditModal({ item, categories, onSave, onClose }) {
    const [editedItem, setEditedItem] = useState(item);
    const [contactImageFile, setContactImageFile] = useState(null);
    const [toolImageFile, setToolImageFile] = useState(null);

    useEffect(() => {
        setEditedItem(item);
    }, [item]);

    if (!item) return null;

    const handleChange = (e) => {
        const { name, value } = e.target;
        setEditedItem(prev => ({ ...prev, [name]: value }));
    };

    const handleSave = (e) => {
        e.preventDefault();
        const formData = new FormData();

        // Append all text fields from state
        for (const key in editedItem) {
            formData.append(key, editedItem[key]);
        }

        // Append new files if they exist
        if (contactImageFile) {
            formData.append('contact_image', contactImageFile);
        }
        if (toolImageFile) {
            formData.append('tool_image', toolImageFile);
        }

        onSave(formData);
    };

    return (
        <div className="modal-backdrop">
            <div className="modal-content">
                <h2>Editar Registro</h2>
                <form onSubmit={handleSave}>
                    {/* Form fields... */}
                    <div className="form-group">
                        <label>Categoría</label>
                        <select name="category" value={editedItem.category} onChange={handleChange}>
                            {categories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                        </select>
                    </div>
                    <div className="form-group">
                        <label>Nº Contacto</label>
                        <input type="text" name="contact_number" value={editedItem.contact_number} onChange={handleChange} required />
                    </div>
                    <div className="form-group">
                        <label>Nº Parte Herramienta</label>
                        <input type="text" name="tool_part_number" value={editedItem.tool_part_number} onChange={handleChange} required />
                    </div>
                    <div className="form-group">
                        <label>Comentarios</label>
                        <input type="text" name="comments" value={editedItem.comments} onChange={handleChange} />
                    </div>

                    {/* Image Fields */}
                    <div className="form-group">
                        <label>Imagen Contacto</label>
                        <ImageCell imageName={editedItem.contact_image} />
                        <input type="file" name="contact_image_file" onChange={(e) => setContactImageFile(e.target.files[0])} accept="image/*" />
                    </div>
                     <div className="form-group">
                        <label>Imagen Herramienta</label>
                        <ImageCell imageName={editedItem.tool_image} />
                        <input type="file" name="tool_image_file" onChange={(e) => setToolImageFile(e.target.files[0])} accept="image/*" />
                    </div>

                    <div className="modal-actions">
                        <button type="button" onClick={onClose}>Cancelar</button>
                        <button type="submit">Guardar Cambios</button>
                    </div>
                </form>
            </div>
        </div>
    );
}

export default EditModal;
