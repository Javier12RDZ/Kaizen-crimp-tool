import React, { useState, useEffect } from 'react';

const ImageCell = ({ imageName, onViewImage }) => {
    if (!imageName) return <p>Sin imagen</p>;
    const imageUrl = `http://localhost:3001/uploads/${imageName}`;
    return (
        <img 
            src={imageUrl} 
            alt={imageName} 
            className="table-image" 
            onClick={() => onViewImage(imageUrl)}
            style={{ cursor: 'pointer' }}
        />
    );
};

function EditModal({ item, categories, onSave, onClose, onViewImage }) {
    // The form is now mostly uncontrolled, but we still need state for controlled inputs
    // to reflect changes.
    const [editedItem, setEditedItem] = useState(item);

    useEffect(() => {
        setEditedItem(item);
    }, [item]);

    if (!item) return null;

    const handleChange = (e) => {
        const { name, value } = e.target;
        setEditedItem(prev => ({ ...prev, [name]: value }));
    };

    const handleSave = (e) => {
        e.preventDefault();
        // Create FormData directly from the form element.
        // This correctly captures all fields, including the hidden 'id' and files.
        const formData = new FormData(e.target);
        onSave(formData);
    };

    return (
        <div className="modal-backdrop">
            <div className="modal-content">
                <h2>Editar Registro</h2>
                {/* The form now creates FormData from its fields on submit */}
                <form onSubmit={handleSave}>
                    {/* Hidden input to ensure the ID is submitted */}
                    <input type="hidden" name="id" value={editedItem.id} />

                    <div className="form-group">
                        <label>Categoría</label>
                        <input 
                            type="text" 
                            name="category" 
                            value={editedItem.category} 
                            onChange={handleChange} 
                            list="category-suggestions"
                            required 
                        />
                        <datalist id="category-suggestions">
                            {categories.map(cat => <option key={cat} value={cat} />)}
                        </datalist>
                    </div>
                    <div className="form-group">
                        <label>Nº Contacto</label>
                        <input type="text" name="contact_number" value={editedItem.contact_number} onChange={handleChange} required />
                    </div>
                    <div className="form-group">
                        <label>Nº Parte Herramienta</label>
                        <input type="text" name="tool_part_number" value={editedItem.tool_part_number} onChange={handleChange} required />
                    </div>
                    <div className="form-group">
                        <label>Comentarios</label>
                        <input type="text" name="comments" value={editedItem.comments || ''} onChange={handleChange} />
                    </div>

                    {/* Image Fields - name attributes must match what the server expects */}
                    <div className="form-group">
                        <label>Imagen Contacto</label>
                        <ImageCell imageName={editedItem.contact_image} onViewImage={onViewImage} />
                        <input type="file" name="contact_image" accept="image/*" />
                    </div>
                     <div className="form-group">
                        <label>Imagen Herramienta</label>
                        <ImageCell imageName={editedItem.tool_image} onViewImage={onViewImage} />
                        <input type="file" name="tool_image" accept="image/*" />
                    </div>

                    <div className="modal-actions">
                        <button type="button" onClick={onClose}>Cancelar</button>
                        <button type="submit">Guardar Cambios</button>
                    </div>
                </form>
            </div>
        </div>
    );
}

export default EditModal;