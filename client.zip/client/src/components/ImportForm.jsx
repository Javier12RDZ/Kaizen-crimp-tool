import React, { useState } from 'react';

function ImportForm({ onImportSuccess }) {
    const [file, setFile] = useState(null);
    const [message, setMessage] = useState('');

    const handleFileChange = (e) => {
        setFile(e.target.files[0]);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!file) {
            setMessage('Por favor, selecciona un archivo.');
            return;
        }

        const formData = new FormData();
        formData.append('file', file);
        formData.append('version', currentVersion);

        try {
            setMessage('Importando...');
            const response = await fetch('http://localhost:3001/api/import', {
                method: 'POST',
                body: formData,
            });

            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.message || 'Error al importar');
            }

            setMessage(`¡Éxito! Se importaron ${result.itemCount} registros.`);
            if (onImportSuccess) {
                onImportSuccess(); // Notify parent to refetch data
            }

        } catch (error) {
            setMessage(`Error: ${error.message}`);
            console.error('Import error:', error);
        }
    };

    return (
        <div className="import-form">
            <h3>Importar desde Excel</h3>
            <form onSubmit={handleSubmit}>
                <input type="file" onChange={handleFileChange} accept=".xlsx, .xls" />
                <button type="submit">Importar</button>
            </form>
            {message && <p>{message}</p>}
        </div>
    );
}

export default ImportForm;
