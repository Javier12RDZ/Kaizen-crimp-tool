import { useNavigate } from 'react-router-dom';
import AddItemForm from '../components/AddItemForm';
import ImportForm from '../components/ImportForm';

function AddRecordPage({ categories, currentVersion, onItemAdded }) {
  const navigate = useNavigate();

  const handleSuccessAndNavigate = () => {
    onItemAdded(); // This is fetchData from App.jsx
    navigate('/'); // Navigate back to home
  };

  return (
    <div className="App">
        <header className="App-header">
            <h1>Agregar / Importar Registros</h1>
        </header>
        <main>
            <div className="forms-container-vertical">
                <div className="form-section">
                    <h2>Importar desde Excel</h2>
                    <ImportForm
                        onImportSuccess={handleSuccessAndNavigate}
                        currentVersion={currentVersion}
                    />
                </div>
                <hr />
                <div className="form-section">
                    <h2>Agregar un solo registro</h2>
                    <AddItemForm
                        categories={categories}
                        onItemAdded={handleSuccessAndNavigate}
                        currentVersion={currentVersion}
                    />
                </div>
            </div>
            <button onClick={() => navigate('/')} style={{marginTop: '20px'}}>Volver a la lista</button>
        </main>
    </div>
  );
}

export default AddRecordPage;
