import React, { useState } from 'react';
import EditableImage from './EditableImage';
import RichTextInput from './RichTextInput';

function AddItemForm({ categories, onItemAdded, currentVersion, onViewImage }) {
    const [message, setMessage] = useState('');
    const [selectedCategory, setSelectedCategory] = useState('');
    const [newCategory, setNewCategory] = useState('');
    const [comments, setComments] = useState('');
    const [contactImage, setContactImage] = useState(null);
    const [toolImage, setToolImage] = useState(null);
    const [dadoImage, setDadoImage] = useState(null);

    const API_BASE_URL = `http://${window.location.hostname}:3001`;

    const handleSubmit = async (e) => {
        e.preventDefault();
        setMessage('');

        const form = e.target;
        const formData = new FormData(form);
        const finalCategory = selectedCategory === '__NEW__' ? newCategory : selectedCategory;

        if (!finalCategory) {
            setMessage('La categoría no puede estar vacía.');
            return;
        }

        formData.set('category', finalCategory);
        formData.append('version', currentVersion);

        // Append files from state
        if (contactImage) {
            formData.append('contact_image', contactImage);
        }
        if (toolImage) {
            formData.append('tool_image', toolImage);
        }
        if (dadoImage) {
            formData.append('dado_image', dadoImage);
        }
        
        // Remove fields that are not part of the final form data
        formData.delete('category_select');
        formData.delete('new_category_name');


        try {
            const response = await fetch(`${API_BASE_URL}/api/items`, {
                method: 'POST',
                body: formData,
            });

            if (response.ok) {
                setMessage('Registro agregado con éxito.');
                form.reset();
                setNewCategory('');
                setComments('');
                setSelectedCategory(categories[0] || '');
                setContactImage(null);
                setToolImage(null);
                setDadoImage(null);
                // We need to manually reset the file upload components
                // This is a limitation of this simple implementation. A more robust
                // solution might involve a key prop on FileUpload to force re-mount.
                if (onItemAdded) onItemAdded();
                return;
            }

            const result = await response.json();
            if (response.status === 409) {
                setMessage('Los datos cambiaron. Intente guardar de nuevo.');
                if (onItemAdded) onItemAdded();
            }

        } catch (error) {
            setMessage(`Error: ${error.message}`);
            console.error('Add item error:', error);
        }
    };

    return (
        <div className="add-item-form">
            <h3>Agregar Nuevo Registro</h3>
            <form onSubmit={handleSubmit}>
                <select value={selectedCategory} onChange={(e) => setSelectedCategory(e.target.value)} name="category_select" required>
                    <option value="" disabled>-- Seleccione una categoría --</option>
                    {categories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                    <option value="__NEW__">-- Nueva Categoría --</option>
                </select>

                {selectedCategory === '__NEW__' && (
                    <input 
                        type="text" 
                        name="new_category_name" 
                        placeholder="Nombre de la nueva categoría" 
                        value={newCategory} 
                        onChange={(e) => setNewCategory(e.target.value)} 
                        required 
                    />
                )}

                <input type="text" name="contact_number" placeholder="Nº Contacto" required />
                <input type="text" name="tool_part_number" placeholder="Nº Parte Herramienta" required />
                <input type="text" name="dado_number" placeholder="Nº Dado" />
                <label>Comentarios</label>
                <RichTextInput value={comments} onChange={setComments} />
                <input type="hidden" name="comments" value={comments} />
                
                <EditableImage
                    label="Imagen Contacto"
                    onNewFile={setContactImage}
                    newFile={contactImage}
                    onImageDeleted={() => setContactImage(null)}
                    onViewImage={onViewImage}
                />
                <EditableImage
                    label="Imagen Herramienta"
                    onNewFile={setToolImage}
                    newFile={toolImage}
                    onImageDeleted={() => setToolImage(null)}
                    onViewImage={onViewImage}
                />
                <EditableImage
                    label="Imagen Dado"
                    onNewFile={setDadoImage}
                    newFile={dadoImage}
                    onImageDeleted={() => setDadoImage(null)}
                    onViewImage={onViewImage}
                />

                <button type="submit">Agregar Registro</button>
            </form>
            {message && <p>{message}</p>}
        </div>
    );
}

export default AddItemForm;
