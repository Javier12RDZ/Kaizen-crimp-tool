import React from 'react';

const API_BASE_URL = `http://${window.location.hostname}:3001`;

const ImageCell = ({ imageName, onViewImage }) => {
    if (!imageName) return null;
    const imageUrl = `${API_BASE_URL}/uploads/${imageName}`;
    return (
        <img 
            src={imageUrl} 
            alt={imageName} 
            className="table-image" 
            onClick={() => onViewImage(imageUrl)}
            style={{ cursor: 'pointer' }}
        />
    );
};

function DataTable({ items, onEdit, onDelete, onViewImage }) {
    if (!items || items.length === 0) {
        return <p>No hay datos para mostrar.</p>;
    }

    const handleCommentClick = (e) => {
        if (e.target.tagName === 'IMG') {
            onViewImage(e.target.src);
        }
    };

    return (
        <table className="data-table">
            <thead>
                <tr>
                    <th>Categoría</th>
                    <th>Nº Contacto</th>
                    <th>Imagen Contacto</th>
                    <th>Nº Parte Herramienta</th>
                    <th>Imagen Herramienta</th>
                    <th>Nº Dado</th>
                    <th>Imagen Dado</th>
                    <th>Comentarios</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                {items.map((item) => (
                    <tr key={item.id}>
                        <td>{item.category}</td>
                        <td>{item.contact_number}</td>
                        <td><ImageCell imageName={item.contact_image} onViewImage={onViewImage} /></td>
                        <td>{item.tool_part_number}</td>
                        <td><ImageCell imageName={item.tool_image} onViewImage={onViewImage} /></td>
                        <td>{item.dado_number}</td>
                        <td><ImageCell imageName={item.dado_image} onViewImage={onViewImage} /></td>
                        <td dangerouslySetInnerHTML={{ __html: item.comments }} onClick={handleCommentClick} style={{ cursor: 'pointer' }} ></td>
                        <td className="actions-cell">
                            <button onClick={() => onEdit(item)} className="edit-btn">
                                Editar
                            </button>
                            <button onClick={() => onDelete(item.id)} className="delete-btn">
                                Eliminar
                            </button>
                        </td>
                    </tr>
                ))}
            </tbody>
        </table>
    );
}

export default DataTable;
