import React, { useState, useEffect } from 'react';
import FileUpload from './FileUpload'; // Import the new component
import RichTextInput from './RichTextInput';

const API_BASE_URL = `http://${window.location.hostname}:3001`;

import EditableImage from './EditableImage';

function EditModal({ item, categories, onSave, onClose, onViewImage }) {
    const [editedItem, setEditedItem] = useState(item);
    const [deletedImages, setDeletedImages] = useState({});
    // State for new file uploads
    const [newContactImage, setNewContactImage] = useState(null);
    const [newToolImage, setNewToolImage] = useState(null);
    const [newDadoImage, setNewDadoImage] = useState(null);

    useEffect(() => {
        setEditedItem(item);
        // Reset states when a new item is loaded into the modal
        setDeletedImages({});
        setNewContactImage(null);
        setNewToolImage(null);
        setNewDadoImage(null);
    }, [item]);

    if (!item) return null;

    const handleChange = (e) => {
        const { name, value } = e.target;
        setEditedItem(prev => ({ ...prev, [name]: value }));
    };

    const handleImageDeleted = (imageType) => {
        setEditedItem(prev => ({ ...prev, [imageType]: null }));
        setDeletedImages(prev => ({ ...prev, [imageType]: true }));
    };

    const handleSave = (e) => {
        e.preventDefault();
        const formData = new FormData(e.target);

        // Append flags for deleted images
        for (const imageType in deletedImages) {
            if (deletedImages[imageType]) {
                formData.append(`delete_${imageType}`, 'true');
            }
        }

        // Append new images if they exist
        if (newContactImage) {
            formData.append('contact_image', newContactImage);
        }
        if (newToolImage) {
            formData.append('tool_image', newToolImage);
        }
        if (newDadoImage) {
            formData.append('dado_image', newDadoImage);
        }

        onSave(formData);
    };

    return (
        <div className="modal-backdrop">
            <div className="modal-content">
                <h2>Editar Registro</h2>
                <form onSubmit={handleSave}>
                    <input type="hidden" name="id" value={editedItem.id} />

                    <div className="form-group">
                        <label>Categoría</label>
                        <input 
                            type="text" 
                            name="category" 
                            value={editedItem.category} 
                            onChange={handleChange} 
                            list="category-suggestions"
                            required 
                        />
                        <datalist id="category-suggestions">
                            {categories.map(cat => <option key={cat} value={cat} />)}
                        </datalist>
                    </div>
                    <div className="form-group">
                        <label>Nº Contacto</label>
                        <input type="text" name="contact_number" value={editedItem.contact_number} onChange={handleChange} required />
                    </div>
                    <div className="form-group">
                        <label>Nº Parte Herramienta</label>
                        <input type="text" name="tool_part_number" value={editedItem.tool_part_number} onChange={handleChange} required />
                    </div>
                    <div className="form-group">
                        <label>Nº Dado</label>
                        <input type="text" name="dado_number" value={editedItem.dado_number || ''} onChange={handleChange} />
                    </div>
                    <div className="form-group">
                        <label>Comentarios</label>
                        <RichTextInput
                            value={editedItem.comments || ''}
                            onChange={(html) => handleChange({ target: { name: 'comments', value: html } })}
                        />
                        <input type="hidden" name="comments" value={editedItem.comments || ''} />
                    </div>

                    <EditableImage
                        label="Imagen Contacto"
                        imageName={editedItem.contact_image} 
                        imageType="contact_image" 
                        onViewImage={onViewImage} 
                        onImageDeleted={handleImageDeleted}
                        onNewFile={setNewContactImage}
                        newFile={newContactImage}
                    />
                    <EditableImage 
                        label="Imagen Herramienta"
                        imageType="tool_image" 
                        onViewImage={onViewImage} 
                        onImageDeleted={handleImageDeleted}
                        onNewFile={setNewToolImage}
                        newFile={newToolImage}
                    />
                    <EditableImage 
                        label="Imagen Dado"
                        imageType="dado_image" 
                        onViewImage={onViewImage} 
                        onImageDeleted={handleImageDeleted}
                        onNewFile={setNewDadoImage}
                        newFile={newDadoImage}
                    />

                    <div className="modal-actions">
                        <button type="button" onClick={onClose}>Cancelar</button>
                        <button type="submit">Guardar Cambios</button>
                    </div>
                </form>
            </div>
        </div>
    );
}

export default EditModal;
