import React, { useState, useEffect } from 'react';
import FileUpload from './FileUpload';
import './EditableImage.css'; // Import the new CSS

const API_BASE_URL = `http://${window.location.hostname}:3001`;

const EditableImage = ({
  imageName,
  imageType,
  onViewImage,
  onImageDeleted,
  onNewFile,
  newFile,
  label
}) => {
  const [previewUrl, setPreviewUrl] = useState(null);

  useEffect(() => {
    if (newFile) {
      const url = URL.createObjectURL(newFile);
      setPreviewUrl(url);
      return () => URL.revokeObjectURL(url);
    } else {
      setPreviewUrl(null);
    }
  }, [newFile]);

  const existingImageUrl = imageName ? `${API_BASE_URL}/uploads/${imageName}` : null;
  const displayUrl = previewUrl || existingImageUrl;

  const handlePaste = (event) => {
    const items = (event.clipboardData || window.clipboardData).items;
    for (let index in items) {
      const item = items[index];
      if (item.kind === 'file' && item.type.startsWith('image/')) {
        event.preventDefault();
        const file = item.getAsFile();
        onNewFile(file);
        return; // Handle one image at a time
      }
    }
  };

  const handleDelete = () => {
    if (newFile) {
      onNewFile(null); // Just clear the new file
    } else if (imageName && onImageDeleted) {
      onImageDeleted(imageType); // Mark existing image for deletion
    }
  };

  return (
    <div className="form-group">
      <label>{label}</label>
      <div className="image-paste-box" onPaste={handlePaste}>
        {displayUrl ? (
          <img
            src={displayUrl}
            alt="Preview"
            onClick={() => onViewImage && onViewImage(displayUrl)}
            style={{ cursor: 'pointer' }}
          />
        ) : (
          <p>Pega una imagen aquí</p>
        )}
      </div>
      <div className="image-buttons">
        <FileUpload
          label="Seleccionar archivo"
          onFileAccepted={onNewFile}
        />
        {displayUrl && (
          <button type="button" className="delete-btn" onClick={handleDelete}>
            Eliminar Imagen
          </button>
        )}
      </div>
    </div>
  );
};

export default EditableImage;
