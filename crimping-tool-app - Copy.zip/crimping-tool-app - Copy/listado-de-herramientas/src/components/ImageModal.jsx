import React from 'react';
import './ImageModal.css';

function ImageModal({ imageUrl, onClose }) {
  if (!imageUrl) return null;

  return (
    <div className="image-modal-backdrop" onClick={onClose}>
      <div className="image-modal-content" onClick={(e) => e.stopPropagation()}>
        <button className="image-modal-close" onClick={onClose}>&times;</button>
        <img src={imageUrl} alt="Vista ampliada" className="image-modal-image" />
      </div>
    </div>
  );
}

export default ImageModal;
