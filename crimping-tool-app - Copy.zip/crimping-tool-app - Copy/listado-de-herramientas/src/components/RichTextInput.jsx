import React, { useRef, useEffect } from 'react';
import './RichTextInput.css';

const API_BASE_URL = `http://${window.location.hostname}:3001`;

const RichTextInput = ({ value, onChange }) => {
    const editorRef = useRef(null);

    useEffect(() => {
        // Synchronize the div content with the value prop, but only if it differs.
        // This is to avoid resetting the cursor position during typing.
        if (editorRef.current && editorRef.current.innerHTML !== value) {
            editorRef.current.innerHTML = value || '';
        }
    }, [value]);

    const handleInput = () => {
        if (onChange) {
            onChange(editorRef.current.innerHTML);
        }
    };

    const handlePaste = async (event) => {
        const items = (event.clipboardData || window.clipboardData).items;
        for (let index in items) {
            const item = items[index];
            if (item.kind === 'file') {
                event.preventDefault();
                const blob = item.getAsFile();
                const formData = new FormData();
                formData.append('image', blob);

                try {
                    const response = await fetch(`${API_BASE_URL}/api/images/upload`, {
                        method: 'POST',
                        body: formData,
                    });
                    if (!response.ok) {
                        throw new Error('Image upload failed');
                    }
                    const result = await response.json();
                    const imageUrl = `${API_BASE_URL}/uploads/${result.filename}`;
                    
                    // Insert image at cursor position
                    const img = document.createElement('img');
                    img.src = imageUrl;
                    img.style.maxWidth = '200px'; // Add some style to the preview
                    
                    const selection = window.getSelection();
                    if (selection.getRangeAt && selection.rangeCount) {
                        const range = selection.getRangeAt(0);
                        range.deleteContents();
                        range.insertNode(img);
                        // Move cursor after the image
                        const newRange = document.createRange();
                        newRange.setStartAfter(img);
                        newRange.collapse(true);
                        selection.removeAllRanges();
                        selection.addRange(newRange);
                    }
                    
                    // Trigger change
                    handleInput();

                } catch (error) {
                    console.error('Error uploading pasted image:', error);
                    alert('Error al subir la imagen pegada.');
                }
            }
        }
    };

    return (
        <div
            ref={editorRef}
            className="rich-text-input"
            contentEditable={true}
            onInput={handleInput}
            onPaste={handlePaste}
        />
    );
};

export default RichTextInput;
