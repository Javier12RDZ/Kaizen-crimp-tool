
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const xlsx = require('xlsx');

// Multer setup for file uploads
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/')
    },
    filename: function (req, file, cb) {
        // Create a unique filename to avoid overwrites
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
});

const upload = multer({ storage: storage });

const app = express();
const PORT = 3001;

// Middleware
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Database path
const DB_PATH = path.join(__dirname, 'db.json');

// Ensure database file and uploads directory exist
const UPLOADS_DIR = path.join(__dirname, 'uploads');
if (!fs.existsSync(UPLOADS_DIR)) {
    fs.mkdirSync(UPLOADS_DIR);
}
if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify({ items: [], version: 0 }, null, 2));
}

// Basic route
app.get('/', (req, res) => {
    res.send('Servidor de la aplicación de crimpeado funcionando.');
});

// API routes will be added here

// Get all items
app.get('/api/items', (req, res) => {
    fs.readFile(DB_PATH, 'utf8', (err, data) => {
        if (err) {
            console.error('Error reading database:', err);
            return res.status(500).json({ message: 'Error reading database' });
        }
        res.json(JSON.parse(data)); // Send whole DB object including version
    });
});

// Import data from Excel
app.post('/api/import', upload.single('file'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ message: 'No file uploaded.' });
    }

    const clientVersion = parseInt(req.body.version, 10);
    const filePath = req.file.path;

    try {
        fs.readFile(DB_PATH, 'utf8', (err, data) => {
            if (err) return res.status(500).json({ message: 'Error reading database' });

            const db = JSON.parse(data);
            if (clientVersion !== db.version) {
                return res.status(409).json({ message: 'Conflict: Data has been modified by another user. Please reload.' });
            }

            // All good, proceed with import
            const workbook = xlsx.readFile(filePath);
            const allItems = [];
            workbook.SheetNames.forEach(sheetName => {
                const sheet = xlsx.utils.sheet_to_json(workbook.Sheets[sheetName], { header: 1 });
                for (let i = 1; i < sheet.length; i++) {
                    const row = sheet[i];
                    if (row.length > 0) {
                        allItems.push({
                            id: `${sheetName}-${i}`,
                            category: sheetName,
                            contact_number: row[0] || '',
                            contact_image: row[1] || '',
                            tool_part_number: row[2] || '',
                            tool_image: row[3] || '',
                            comments: row[4] || ''
                        });
                    }
                }
            });

            db.items = allItems;
            db.version++; // Increment version

            fs.writeFile(DB_PATH, JSON.stringify(db, null, 2), (writeErr) => {
                if (writeErr) return res.status(500).json({ message: 'Error saving data' });
                res.status(200).json({ message: 'Data imported successfully', itemCount: allItems.length });
            });
        });
    } catch (error) {
        console.error('Error processing Excel file:', error);
        res.status(500).json({ message: 'Error processing file' });
    } finally {
        fs.unlink(filePath, (unlinkErr) => {
            if (unlinkErr) console.error('Error deleting temp file:', unlinkErr);
        });
    }
});

// Delete an item
app.delete('/api/items/:id', (req, res) => {
    const itemId = req.params.id;
    const clientVersion = req.body.version;

    fs.readFile(DB_PATH, 'utf8', (err, data) => {
        if (err) return res.status(500).json({ message: 'Error reading database' });
        
        const db = JSON.parse(data);

        if (clientVersion !== db.version) {
            return res.status(409).json({ message: 'Conflict: Data has been modified by another user. Please reload.' });
        }

        const initialLength = db.items.length;
        db.items = db.items.filter(item => item.id !== itemId);

        if (db.items.length === initialLength) {
            return res.status(404).json({ message: 'Item not found' });
        }

        db.version++; // Increment version

        fs.writeFile(DB_PATH, JSON.stringify(db, null, 2), (writeErr) => {
            if (writeErr) return res.status(500).json({ message: 'Error writing to database' });
            res.status(200).json({ message: 'Item deleted successfully' });
        });
    });
});

// Add a new item
app.post('/api/items', upload.fields([{ name: 'contact_image', maxCount: 1 }, { name: 'tool_image', maxCount: 1 }]), (req, res) => {
    try {
        const newItemData = req.body;
        const clientVersion = parseInt(newItemData.version, 10);

        if (!newItemData || !newItemData.contact_number || !newItemData.tool_part_number) {
            return res.status(400).json({ message: 'Contact number and tool part number are required.' });
        }

        // Image handling...
        if (req.files['contact_image']) newItemData.contact_image = req.files['contact_image'][0].filename;
        if (req.files['tool_image']) newItemData.tool_image = req.files['tool_image'][0].filename;

        fs.readFile(DB_PATH, 'utf8', (err, data) => {
            if (err) return res.status(500).json({ message: 'Error reading database' });
            
            const db = JSON.parse(data);

            if (clientVersion !== db.version) {
                return res.status(409).json({ message: 'Conflict: Data has been modified by another user. Please reload.' });
            }

            newItemData.id = `${newItemData.category || 'cat'}-${Date.now()}`;
            db.items.push(newItemData);
            db.version++; // Increment version

            fs.writeFile(DB_PATH, JSON.stringify(db, null, 2), (writeErr) => {
                if (writeErr) return res.status(500).json({ message: 'Error writing to database' });
                res.status(201).json(newItemData);
            });
        });
    } catch (error) {
        console.error("Server Error on POST /api/items:", error);
        res.status(500).json({ message: 'An unexpected server error occurred.', error: error.message });
    }
});

// Update an item
app.put('/api/items/:id', upload.fields([{ name: 'contact_image', maxCount: 1 }, { name: 'tool_image', maxCount: 1 }]), (req, res) => {
    try {
        const itemId = req.params.id;
        const updatedItemData = req.body;
        const clientVersion = parseInt(updatedItemData.version, 10);

        fs.readFile(DB_PATH, 'utf8', (err, data) => {
            if (err) return res.status(500).json({ message: 'Error reading database' });
            
            const db = JSON.parse(data);

            if (clientVersion !== db.version) {
                return res.status(409).json({ message: 'Conflict: Data has been modified by another user. Please reload.' });
            }

            const itemIndex = db.items.findIndex(item => item.id === itemId);
            if (itemIndex === -1) return res.status(404).json({ message: 'Item not found' });

            const originalItem = db.items[itemIndex];

            // Image handling...
            if (req.files['contact_image']) {
                if (originalItem.contact_image) fs.unlink(path.join(__dirname, 'uploads', originalItem.contact_image), e => e && console.error(e));
                updatedItemData.contact_image = req.files['contact_image'][0].filename;
            }
            if (req.files['tool_image']) {
                if (originalItem.tool_image) fs.unlink(path.join(__dirname, 'uploads', originalItem.tool_image), e => e && console.error(e));
                updatedItemData.tool_image = req.files['tool_image'][0].filename;
            }

            db.version++; // Increment version
            db.items[itemIndex] = { ...originalItem, ...updatedItemData };

            fs.writeFile(DB_PATH, JSON.stringify(db, null, 2), (writeErr) => {
                if (writeErr) return res.status(500).json({ message: 'Error writing to database' });
                res.status(200).json(db.items[itemIndex]);
            });
        });
    } catch (error) {
        console.error("Server Error on PUT /api/items:", error);
        res.status(500).json({ message: 'An unexpected server error occurred.', error: error.message });
    }
});

// --- Production-only routes ---
// Serve React App build files
app.use(express.static(path.join(__dirname, '../client/dist')));

// For any request that doesn't match an API route, send back React's index.html file
app.get(/^(?!\/api).*/, (req, res) => {
    res.sendFile(path.join(__dirname, '../client/dist', 'index.html'));
});


app.listen(PORT, '0.0.0.0', () => {
    console.log(`Servidor escuchando en http://localhost:${PORT}`);
    console.log(`También accesible en tu red local. Usa tu IP para conectar desde otros dispositivos.`);
});
