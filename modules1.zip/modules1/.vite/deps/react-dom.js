import {
  require_react_dom
} from "./chunk-ZEJDETLQ.js";
import "./chunk-AQI5YXZE.js";
export default require_react_dom();
