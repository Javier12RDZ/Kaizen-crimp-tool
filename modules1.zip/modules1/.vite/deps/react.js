import {
  require_react
} from "./chunk-AQI5YXZE.js";
export default require_react();
