export default function accept(file: { name?: string, type?: string }, acceptedFiles: string | string[]): boolean;
